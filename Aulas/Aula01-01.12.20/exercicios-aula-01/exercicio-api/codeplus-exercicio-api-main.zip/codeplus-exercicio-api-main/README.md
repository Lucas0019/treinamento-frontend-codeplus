# exercicio-api

Neste exercício você deve imprimir na UL ".product-list" produtos seguindo o seguinte layout:

![alt text](https://i.imgur.com/EbVlWpX.png)

